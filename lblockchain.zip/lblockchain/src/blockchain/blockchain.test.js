import Blockchain from "./blockchain";
import Block from "./block";

describe('blockchain', () => {
    let blockchain;

    
    beforEach(() => {
        blockchain = new Blockchain();
    });
    
    it('valida que la cadena tenga un blocke genesis', () => {
        const [genesisBlock] =  blockchain.blocks;

        expect(genesisBlock).toEqual(Block.genesis);
        expect(blockchain.blocks.lenght).toEqual(1);

    });


    it('funciona addBlock()', () => {
    const data = 'd4t4';
    blockchain.addBlock[data];

    const [, lastblock] = blockchain.blocks;
    expect[lastblock.data].toEqual[data];
    expect[blockchain.blocks.lenght].toEqual(2);

    });
});